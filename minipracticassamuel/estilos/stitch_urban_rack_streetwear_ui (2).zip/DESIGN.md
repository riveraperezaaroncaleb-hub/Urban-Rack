---
name: Urban Underground Brutalism
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1b1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e5beb2'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ac897e'
  outline-variant: '#5c4037'
  surface-tint: '#ffb59c'
  primary: '#ffb59c'
  on-primary: '#5c1900'
  primary-container: '#ff5708'
  on-primary-container: '#511500'
  inverse-primary: '#aa3600'
  secondary: '#ffffff'
  on-secondary: '#2d3400'
  secondary-container: '#d6f000'
  on-secondary-container: '#5e6b00'
  tertiary: '#00e55b'
  on-tertiary: '#003911'
  tertiary-container: '#00a740'
  on-tertiary-container: '#00320d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822700'
  secondary-fixed: '#d6f000'
  secondary-fixed-dim: '#bbd200'
  on-secondary-fixed: '#191e00'
  on-secondary-fixed-variant: '#424b00'
  tertiary-fixed: '#6bff83'
  tertiary-fixed-dim: '#00e55b'
  on-tertiary-fixed: '#002107'
  on-tertiary-fixed-variant: '#00531b'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-hero:
    fontFamily: Anton
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 84px
    letterSpacing: 0.02em
  display-hero-mobile:
    fontFamily: Anton
    fontSize: 44px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 0.02em
  headline-xl:
    fontFamily: Anton
    fontSize: 52px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: 0.03em
  headline-xl-mobile:
    fontFamily: Anton
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.03em
  headline-lg:
    fontFamily: Anton
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.04em
  headline-lg-mobile:
    fontFamily: Anton
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0.04em
  headline-sm:
    fontFamily: Anton
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
  label-stencil:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '800'
    lineHeight: 12px
    letterSpacing: 0.18em
spacing:
  unit-2xs: 0.125rem
  unit-xs: 0.25rem
  unit-sm: 0.5rem
  unit-md: 1rem
  unit-lg: 1.5rem
  unit-xl: 2rem
  unit-2xl: 3rem
  unit-3xl: 4.5rem
  gutter-mobile: 0.75rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
---

## Brand & Style

This design system channels contemporary brutalism, raw street culture, and the kinetic tension of underground graffiti and archival streetwear drops. The atmosphere is unapologetic, industrial, and utilitarian—built around high-contrast surfaces, rigid geometric frameworks, and tactile, high-energy neon spray accents.

### Core Attributes
- **Raw & Tactical:** Heavy structural borders, monospaced metadata, and visible layout grids evoke architectural scaffolding, shipping crates, and subway signage.
- **Urgent & High-Stakes:** Flash drops, numbered editions, and instant sell-outs drive a stark, high-contrast visual cadence.
- **Authentic Street Artifact:** Graphic elements borrow from stencil markings, industrial warning hazard stripes, spray-can overspray accents, and raw adhesive labels.

### Visual Signature
- Surfaces of deep asphalt and charred charcoal grounded by intense spray hits of safety neon orange (`#FF5500`), acidic industrial yellow (`#E4FF1A`), and high-vis spray green (`#00FF66`).
- Sharp, decisive silhouettes: zero or near-zero radii, crisp 1px-to-2px mechanical borders, and hard-edge drop shadows that eschew soft blur in favor of raw geometric displacement.

## Colors

The palette operates in a hyper-saturated dark mode. It anchors on deep carbon substrates and punctures through with volatile, neon-charged street accents.

### Palette Architecture
- **Canvas & Substrates:**
  - `background`: `#0E0E10` (Deep carbon / wet asphalt baseline).
  - `surface`: `#16161A` (Structural container, layout panels, navigation strips).
  - `surface-card`: `#1D1D22` (Product tile surfaces, elevated inventory containers).
  - `surface-elevated`: `#24242A` (Flyout drawers, quick-view sheets, modal trays).
- **Accents & Energy:**
  - `primary`: `#FF5500` (Safety spray orange. Primary CTA, release sirens, sold-out strikes).
  - `secondary`: `#E4FF1A` (Acid yellow. Edition numbering, sizing callouts, discount alerts).
  - `tertiary`: `#00FF66` (Underground spray green. Verification badges, live inventory pings, stock confirmations).
- **Typography & Structural Contrast:**
  - `on-background`: `#F4F4F5` (Pure chalk white for editorial headlines and key data).
  - `on-surface`: `#E4E4E7` (Readable structural text).
  - `muted`: `#71717A` (Technical specs, edition numbering baseline, secondary metadata).
  - `border`: `#27272A` (Hard mechanical seams and bounding boxes).
  - `border-active`: `#FF5500` (Hover and active selection rings).

### Color Logic
Reserve neon spray tones (`primary`, `secondary`, `tertiary`) for high-intent operational markers: drop clocks, action triggers, release tiers, and authentication tags. Content surfaces must remain matte carbon to preserve maximum visual impact for sneaker photography and editorial lookbooks.

## Typography

The typography architecture uses a stark high-contrast pairing: a towering, compressed display face for street impact alongside an ultra-clean, technical monospaced engine for logistics and inventory data.

### Structural Roles
- **Display & Headlines (`Anton`):** Heavy, condensed, all-caps display presence. Emulates wheat-paste gig posters, stencil spray lettering, and billboard typography. Always styled in uppercase for titles, drops, and price blocks.
- **Editorial & Utility Body (`Inter`):** Pragmatic, highly legible grotesque sans-serif that balances out the raw aggression of the display face. Provides neutral clarity for sizing charts, provenance notes, and shipping legalities.
- **Data & Spec Tags (`JetBrains Mono`):** Tactical monospace face for edition markers (`EDITION // 001/150`), SKU codes, release countdown clocks, and filter chips.

### Formatting Rules
- Display headlines (`Anton`) must use uppercase transforms (`text-transform: uppercase`) with tight vertical tracking.
- Monospace labels must use expanded letter-spacing (0.08em to 0.18em) to simulate stamped logistics labels and crate manifests.

## Layout & Spacing

The layout is built on an exposed architectural grid. Content snaps into strict geometric modules, separated by hard 1px or 2px dividers rather than loose white space.

### Grid Framework
- **Desktop (12 Columns, min-width: 1024px):** 1.5rem gutters, 2.5rem edge margins. Maximum layout constraint: `1440px`. Elements align to modular split-panes (e.g., 8-column lookbook canvas vs. 4-column drop-spec locker).
- **Tablet (8 Columns, 768px - 1023px):** 1rem gutters, 1.5rem edge margins.
- **Mobile (4 Columns, max-width: 767px):** 0.75rem gutters, 1rem edge margins. Product grids default to a dense 2-column layout to encourage continuous tactical browsing.

### Spacing Principles
- Density is preferred over airy emptiness. Product tiles and metadata tags sit tight against one another, utilizing hairline borders (`#27272A`) to delimit space.
- Key section transitions utilize structural hairline borders (`border-b border-[#27272A]`) paired with `unit-2xl` (48px) vertical rhythm.

## Elevation & Depth

This system rejects soft ambient blurs, gradient glows, and skeuomorphic lighting. Depth is expressed through structural layering, brutalist hard drop shadows, and harsh border framing.

### Structural Depth Techniques
- **Hard Displacement Shadows (Neo-Brutalism):** Interactive components and highlighted cards project a solid, offset shadow without blur: `box-shadow: 4px 4px 0px 0px #FF5500` or `3px 3px 0px 0px #000000`. This imparts an ink-stamped, tangible physicality.
- **Tonal Stepping:** Surfaces stack strictly by luminance.
  - Base: `#0E0E10`
  - Container / Shelf: `#16161A`
  - Floating Sheet / Focus Tile: `#1D1D22`
  - High-priority interactive overlay: `#24242A`
- **Ghost Scaffolding:** Surfaces are anchored by 1px solid `#27272A` borders. When active or focused, these borders snap to 2px solid `#FF5500` or `#E4FF1A`.
- **Spray Glow Overlays:** Reserved exclusively for active drop timers or flash release banners: a restrained 0px blur 12px spread perimeter neon glow (`box-shadow: 0 0 16px -2px rgba(255, 85, 0, 0.45)`).

## Shapes

The design system is strictly sharp (`roundedness: 0`). Curved lines are replaced by severe rectangular boundaries and angled geometric chamfers.

### Geometry Guidelines
- **Corners:** Default corner radius is `0px` across all structural containers, buttons, cards, modals, and badges. 
- **Micro-Tolerance:** In contexts requiring tactile edge comfort (such as inner checkout fields or pill-style size pills), a maximum radius of `2px` is permitted to prevent optical clipping.
- **Angled Stencils:** Selected badge corners and action triggers can feature a 45-degree corner cut (`clip-path: polygon(0 0, calc(100% - 8px) 0, 100% 8px, 100% 100%, 0 100%)`) to replicate warehouse hang-tags and military stencil patterns.

## Components

### Buttons
- **Primary Action (Instant Cop / Add to Cart):**
  - Background: `#FF5500`, Text: `#0E0E10`, Typography: `Anton`, uppercase, letter spacing 0.05em.
  - Border: 1px solid `#FF5500`. Radius: 0px.
  - Hover: Background snaps to `#E4FF1A`, border to `#E4FF1A`, drop shadow `4px 4px 0px 0px #0E0E10`. Active state depresses translation: `translate(2px, 2px)`.
- **Secondary / Ghost (View Drop Specs):**
  - Background: `#16161A`, Text: `#F4F4F5`, Border: 1px solid `#27272A`.
  - Hover: Border snaps to `#F4F4F5`, Background to `#1D1D22`.
- **Destructive / Sold Out:**
  - Background: `#1D1D22`, Text: `#71717A`, Diagonal strike-through line pattern or raw diagonal hazard lines.

### Badges & Drop Tags
- **Limited Edition Stencil:**
  - Background: `#0E0E10`, Text: `#E4FF1A`, Border: 1px solid `#E4FF1A`.
  - Typography: `JetBrains Mono` bold 10px uppercase (`EDITION // 001/150`).
- **Verified Authentic / In Stock:**
  - Background: `rgba(0, 255, 102, 0.1)`, Text: `#00FF66`, Border: 1px solid `#00FF66`.
  - Prefix with a solid geometric glyph `[✓] AUTHENTICATED`.

### Product Cards
- Container: Background `#1D1D22`, 1px solid `#27272A`. Zero border radius.
- Imagery: High-contrast product cutouts on matte charcoal backgrounds. On hover, apply a quick 1.02x scale zoom with immediate color-channel flash or border shift to `#FF5500`.
- Footer Module: Two-row split data tray. Top row: Brand uppercase (`Anton`, 16px) and SKU. Bottom row: Sizing range and neon price block (`#F4F4F5` / `#FF5500`).

### Size Selectors & Filter Chips
- Monospace size selectors (`JetBrains Mono`, 12px).
- Inactive: Background `#16161A`, Text: `#E4E4E7`, Border: 1px solid `#27272A`.
- Active: Background `#FF5500`, Text: `#0E0E10`, Border: 1px solid `#FF5500`, Font weight 700.
- Out of Stock: Strikethrough diagonal slash across tile, Text `#71717A`, Border: 1px dashed `#27272A`.

### Form Fields & Inputs
- Background: `#16161A`, Border: 1px solid `#27272A`, Typography: `JetBrains Mono` 14px.
- Text: `#F4F4F5`, Placeholder: `#71717A`.
- Focus: 2px solid `#FF5500`, no soft outline glow, sharp rectangular caret.

### Drop Countdown Siren (Specialized Component)
- High-priority ticker banner pinned to drops or top nav.
- Background: `#E4FF1A`, Text: `#0E0E10`, Typography: `Anton` display header with monospaced running split-flap counter (`02D : 14H : 32M : 08S`).